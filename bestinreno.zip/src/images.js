export default [
  './img/t1.jpg',
  './img/t2.jpg',
  './img/t3.jpg'
]





