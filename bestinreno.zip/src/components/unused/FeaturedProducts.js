import firstPic from '../img/ComponentTMP_0-image7.jpg'
import secondPic from '../img/ComponentTMP_0-image8.jpg'
import thirdPic from '../img/ComponentTMP_0-image9.jpg'
import fourthPic from '../img/ComponentTMP_0-image10.jpg'
import fifthPic from '../img/ComponentTMP_0-image11.png'
import sixthPic from '../img/ComponentTMP_0-image12.jpg'

const firstPrice= 59
const secondPrice= 59
const thirdPrice= 59
const fourthPrice= 59
const fifthPrice= 59
const sixthPrice= 59

export default [
  [firstPic, `$${firstPrice}`],
  [secondPic, `$${secondPrice}`],
  [thirdPic, `$${thirdPrice}`],
  [fourthPic, `$${fourthPrice}`],
  [fifthPic, `$${fifthPrice}`],
  [sixthPic, `$${sixthPrice}`]
]